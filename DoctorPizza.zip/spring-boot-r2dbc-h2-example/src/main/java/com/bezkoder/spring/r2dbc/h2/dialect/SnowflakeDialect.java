package com.bezkoder.spring.r2dbc.h2.dialect;

import org.hibernate.dialect.Dialect;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SnowflakeDialect extends Dialect {


}
